from distutils.core import setup
setup(name="crosswordpuzzle",
      version="1.0rc1",
      description="Crossword puzzle game and editor",
      author="Peter Gebauer",
      author_email="none",
      url="http://launchpad.net/crosswordpuzzle",
      packages=["cwp"],
      scripts=["crosswordpuzzle.py"],
      )

